// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "error"		// replace MySSID with your WiFi network name
#define SECRET_PASS "mayank13"	// replace MyPassword with your WiFi password

#define SECRET_CH_ID 2249000			// replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "G3ACGZOOCSDTNQ6C"   // replace XYZ with your channel write API Key
